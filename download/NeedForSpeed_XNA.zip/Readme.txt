---------------------------------------
Title:		Need for Speed XNA
Author:		Jeff Harris | 1am Studios 
Website:	http://www.1amstudios.com/games/NeedForSpeed/
Email:		jeff@1amstudios.com
---------------------------------------

Need for Speed XNA is an attempt to bring the best game in the Need for Speed series (Need for Speed 1) back to life using C# and XNA.

The code is all mine, but it uses the original Need for Speed data (textures, models, tracks). Information on the file formats was reverse engineered by Denis Auroux (mostly) and myself.


To install:
---------------
Unzip to a folder somewhere and run Setup.exe.  Once it has installed, a Start Menu shortcut will appear and the game will start.

To uninstall:
---------------
Add/Remove Programs


Thanks to:
---------------
Denis Auroux for the NFS file format specs - http://auroux.free.fr/nfs/nfsspecs.txt
Lawrence of "Sharky's Air Legends" - http://sharky.bluecog.co.nz
http://www.ziggyware.com
www.riemers.net/
www.thehazymind.com/
http://xna-uk.net/


Legal:
---------------
All in-race models, textures, tracks, cars by Pioneer Productions / EA Seattle (C) 1995.
Need for Speed XNA is not affiated in any way with EA, Pioneer Productions or Road & Track.

