﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Text.RegularExpressions;

namespace DotfuscatorStackViewer
{
	/// <summary>
	/// Takes a Dotfuscator stack trace and returns an unobfuscated trace using given Map.xml
	/// </summary>
	class StackDeobfuscator
	{
		XmlDocument _mapDocument;
		string _mapFilePath;

		public string MapFilePath
		{
			get { return _mapFilePath; }
			set
			{
				if (_mapFilePath != value)
				{
					_mapDocument = new XmlDocument();
					_mapDocument.XmlResolver = null;
					_mapDocument.Load(value);
				}
				_mapFilePath = value;
			}
		}

		public string Decode(string stack)
		{
			if (_mapDocument == null)
				throw new Exception("MapFilePath must be set before calling Decode()");

			StringBuilder newStack = new StringBuilder();

			Regex regex = new Regex(@"(\s*)(\w*)(\s*)(.*)(\()(.*)(\))", RegexOptions.IgnoreCase); //@"(\s*)(\w*)(\.)(.*)(\()(.*)(\))", RegexOptions.IgnoreCase);
			MatchCollection matches = regex.Matches(stack);

			foreach (Match match in matches)
			{
				string typeName = match.Groups[4].Value;
				typeName = typeName.Substring(0, typeName.LastIndexOf("."));
				string methodName = match.Groups[4].Value.Substring(match.Groups[4].Value.LastIndexOf(".") + 1);

				ObfuscatedType type = GetObfuscatedType(null, typeName);

				if (type == null)
				{
					newStack.AppendLine(match.Value.Trim());
					continue;
				}

				ObfuscatedMethodCall call = new ObfuscatedMethodCall(type, methodName, match.Groups[6].Value, match.Value);

				string decodedLine = call.Deobfuscate();
				newStack.AppendLine(decodedLine);
			}

			return newStack.ToString();
		}

		/// <summary>
		/// Find an obfuscated type in the mapping file.  First look for a nested type, then for a standard type
		/// </summary>
		/// <param name="parentType"></param>
		/// <param name="typeName"></param>
		/// <returns></returns>
		internal ObfuscatedType GetObfuscatedType(ObfuscatedType parentType, string typeName)
		{
			string originalTypeName = typeName;
			if (parentType != null)
				typeName = parentType.ObfuscatedName + "/" + typeName;

			for (int i = 0; i < 2; i++)
			{
				XmlNode typeNode = _mapDocument.SelectSingleNode(String.Format("dotfuscatorMap/mapping/module/type[newname='{0}']", typeName));

				if (typeNode != null)
				{
					return new ObfuscatedType(this) { MappingNode = typeNode, ObfuscatedName = typeName, OriginalName = typeNode["name"].InnerText };
				}
				else
				{
					typeNode = _mapDocument.SelectSingleNode(String.Format("dotfuscatorMap/mapping/module/type[name='{0}']", typeName));
					if (typeNode != null)
						return new ObfuscatedType(this) { MappingNode = typeNode, ObfuscatedName = typeName, OriginalName = typeName };
				}
				if (parentType != null)
					typeName = originalTypeName;
				else
					break;
			}

			return null;
		}


		/// <summary>
		/// Converts the method signature in the map.xml to a signature comparable to a stack trace signature
		/// </summary>
		/// <param name="signature"></param>
		/// <returns></returns>
		internal string CanonicalizeMappingSignature(string signature)
		{
			StringBuilder sb = new StringBuilder();
			string[] args = signature.Substring(signature.IndexOf("(") + 1).Replace(")", "").Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

			signature = System.Web.HttpUtility.HtmlDecode(signature);
			for (int i = 0; i < args.Length; i++)
			{
				args[i] = args[i].Trim();
				if (sb.Length > 0)
					sb.Append(", ");
				if (args[i].Contains("."))
					args[i] = args[i].Substring(args[i].LastIndexOf(".") + 1);
				if (args[i].Contains(" "))
					args[i] = args[i].Substring(0, args[i].IndexOf(" "));
				if (args[i].Contains("<"))
					args[i] = args[i].Substring(0, args[i].IndexOf("<"));
				if (args[i].Contains("/"))
					args[i] = args[i].Substring(args[i].IndexOf("/") + 1);
				sb.Append(args[i]);
			}
			sb.Insert(0, "(");
			sb.Append(")");
			return sb.ToString();
		}
	}
}