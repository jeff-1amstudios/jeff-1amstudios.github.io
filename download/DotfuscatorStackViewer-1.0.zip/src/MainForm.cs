﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace DotfuscatorStackViewer
{
	public partial class MainForm : Form
	{
		StackDeobfuscator _decoder;

		public MainForm()
		{
			InitializeComponent();
			this.FormClosing += new FormClosingEventHandler(MainForm_FormClosing);
			MapPathTextbox.Text = Settings.Instance.LastMapFileUsed;
			EncodedStackTextbox.Focus();

			_decoder = new StackDeobfuscator();
		}

		void MainForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			Settings.Instance.LastMapFileUsed = MapPathTextbox.Text;
			Settings.Instance.Save();
		}

		private void DecodeButton_Click(object sender, EventArgs e)
		{
			_decoder.MapFilePath = MapPathTextbox.Text;
			DecodedStackTextbox.Text = _decoder.Decode(EncodedStackTextbox.Text);
		}


		private void ChooseMapFileButton_Click(object sender, EventArgs e)
		{
			if (openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				MapPathTextbox.Text = openFileDialog1.FileName;
			}
		}

		private void DecodeClipboard_Click(object sender, EventArgs e)
		{
			if (Clipboard.ContainsText())
			{
				string trace = Clipboard.GetText();
				EncodedStackTextbox.Text = trace;
				DecodeButton_Click(this, null);
			}
		}

		private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
		{
			new AboutForm().ShowDialog();
		}

		private void amstudioscomToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Process.Start("http://www.1amstudios.com");
		}

		private void donateToolStripMenuItem_Click(object sender, EventArgs e)
		{
			string url = @"https://www.paypal.com/xclick/&business=jeff%401amstudios.com&item_name=dotfuscator+StackViewer+donation&no_shipping=1&no_note=1&currency_code=USD";
			Process.Start(url);
		}
	}
}
