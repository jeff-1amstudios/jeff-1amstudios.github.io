﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace DotfuscatorStackViewer
{
	public class Settings
	{
		static Settings _instance;

		public string LastMapFileUsed { get; set; }

		public static Settings Instance
		{
			get
			{
				if (_instance == null)
				{
					XmlSerializer serializer = new XmlSerializer(typeof(Settings));
					string path = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "settings.xml");
					if (File.Exists(path))
						using (FileStream fs = File.Open(path, FileMode.Open))
						{
							_instance = (Settings)serializer.Deserialize(fs);
						}
					else
						_instance = new Settings();
				}
				return _instance;
			}
		}

		public void Save()
		{
			XmlSerializer serializer = new XmlSerializer(typeof(Settings));
			string path = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "settings.xml");
			using (FileStream fs = File.Open(path, FileMode.Create))
			{
				serializer.Serialize(fs, this);
			}
		}
	}
}