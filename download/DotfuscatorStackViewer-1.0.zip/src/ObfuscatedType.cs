﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace DotfuscatorStackViewer
{
	class ObfuscatedType
	{
		public XmlNode MappingNode { get; set; }
		public string OriginalName { get; set; }
		public string ObfuscatedName { get; set; }

		private StackDeobfuscator _decoder;

		public ObfuscatedType(StackDeobfuscator decoder)
		{
			_decoder = decoder;
		}

		public string DeobfuscateMethodCall(ObfuscatedMethodCall call)
		{
			string signature = CanonicalizeSignature(call);

			XmlNodeList methodNodes = MappingNode.SelectNodes(String.Format("methodlist/method[name='{0}']", call.MethodName));
			if (methodNodes.Count == 0)
			{
				methodNodes = MappingNode.SelectNodes(String.Format("methodlist/method[newname='{0}']", call.MethodName));
			}
			foreach (XmlNode method in methodNodes)
			{
				if (_decoder.CanonicalizeMappingSignature(method["signature"].InnerText) == signature)
				{
					return call.CallingType.OriginalName + "." + method["name"].InnerText + signature;
				}
			}

			return call.OriginalText.Trim() + " [failed]";
		}

		/// <summary>
		/// Create a method signature comparable to a mapped method signature
		/// </summary>
		/// <param name="call"></param>
		/// <returns></returns>
		internal string CanonicalizeSignature(ObfuscatedMethodCall call)
		{
			StringBuilder sb = new StringBuilder();
			string[] args = call.Args;

			for (int i = 0; i < args.Length; i++)
			{
				args[i] = args[i].Trim();
				if (sb.Length > 0)
					sb.Append(", ");
				if (args[i].Contains(" "))
					args[i] = args[i].Substring(0, args[i].IndexOf(" "));

				ObfuscatedType oft = _decoder.GetObfuscatedType(call.CallingType, args[i]);
				if (oft != null) args[i] = oft.OriginalName;
				if (args[i].Contains("."))
					args[i] = args[i].Substring(args[i].LastIndexOf(".") + 1);

				if (args[i] == "Object") args[i] = "object";
				else if (args[i] == "String") args[i] = "string";
				else if (args[i] == "Byte") args[i] = "byte";
				else if (args[i] == "SByte") args[i] = "sbyte";
				else if (args[i] == "Int32") args[i] = "int32";
				else if (args[i] == "UInt32") args[i] = "uint32";
				else if (args[i] == "Int16") args[i] = "int16";
				else if (args[i] == "UInt16") args[i] = "uint16";
				else if (args[i] == "Int64") args[i] = "int64";
				else if (args[i] == "UInt64") args[i] = "uint64";
				else if (args[i] == "Single") args[i] = "single";
				else if (args[i] == "Double") args[i] = "double";
				else if (args[i] == "Char") args[i] = "char";
				else if (args[i] == "Decimal") args[i] = "decimal";
				else if (args[i] == "Boolean") args[i] = "bool";

				sb.Append(args[i]);
			}
			sb.Insert(0, "(");
			sb.Append(")");
			return sb.ToString();
		}
	}
}