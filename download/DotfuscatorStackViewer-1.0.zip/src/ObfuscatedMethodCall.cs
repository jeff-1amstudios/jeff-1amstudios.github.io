﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotfuscatorStackViewer
{
	class ObfuscatedMethodCall
	{
		public ObfuscatedType CallingType { get; private set; }
		public string MethodName { get; set; }
		public string[] Args { get; private set; }
		public string OriginalText { get; private set; }

		public ObfuscatedMethodCall(ObfuscatedType caller, string methodName, string args, string originalText)
		{
			CallingType = caller;
			MethodName = methodName;
			Args = args.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
			OriginalText = originalText;
		}

		internal string Deobfuscate()
		{
			return CallingType.DeobfuscateMethodCall(this);
		}
	}
}