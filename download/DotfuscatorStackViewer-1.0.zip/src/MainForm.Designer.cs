﻿namespace DotfuscatorStackViewer
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.MapPathTextbox = new System.Windows.Forms.TextBox();
			this.ChooseMapFileButton = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.DecodeButton = new System.Windows.Forms.Button();
			this.DecodedStackTextbox = new System.Windows.Forms.TextBox();
			this.EncodedStackTextbox = new System.Windows.Forms.TextBox();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.DecodeClipboard = new System.Windows.Forms.Button();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.amstudioscomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.donateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.menuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// MapPathTextbox
			// 
			this.MapPathTextbox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.MapPathTextbox.Location = new System.Drawing.Point(120, 28);
			this.MapPathTextbox.Name = "MapPathTextbox";
			this.MapPathTextbox.Size = new System.Drawing.Size(580, 21);
			this.MapPathTextbox.TabIndex = 5;
			// 
			// ChooseMapFileButton
			// 
			this.ChooseMapFileButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.ChooseMapFileButton.Location = new System.Drawing.Point(703, 27);
			this.ChooseMapFileButton.Name = "ChooseMapFileButton";
			this.ChooseMapFileButton.Size = new System.Drawing.Size(27, 22);
			this.ChooseMapFileButton.TabIndex = 6;
			this.ChooseMapFileButton.Text = "...";
			this.ChooseMapFileButton.UseVisualStyleBackColor = true;
			this.ChooseMapFileButton.Click += new System.EventHandler(this.ChooseMapFileButton_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(11, 32);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(108, 13);
			this.label1.TabIndex = 7;
			this.label1.Text = "Dotfuscator map file:";
			// 
			// DecodeButton
			// 
			this.DecodeButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.DecodeButton.Location = new System.Drawing.Point(642, 140);
			this.DecodeButton.Name = "DecodeButton";
			this.DecodeButton.Size = new System.Drawing.Size(75, 23);
			this.DecodeButton.TabIndex = 1;
			this.DecodeButton.Text = "Decode";
			this.DecodeButton.UseVisualStyleBackColor = true;
			this.DecodeButton.Click += new System.EventHandler(this.DecodeButton_Click);
			// 
			// DecodedStackTextbox
			// 
			this.DecodedStackTextbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.DecodedStackTextbox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.DecodedStackTextbox.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.DecodedStackTextbox.Location = new System.Drawing.Point(0, 0);
			this.DecodedStackTextbox.Multiline = true;
			this.DecodedStackTextbox.Name = "DecodedStackTextbox";
			this.DecodedStackTextbox.ReadOnly = true;
			this.DecodedStackTextbox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.DecodedStackTextbox.Size = new System.Drawing.Size(718, 175);
			this.DecodedStackTextbox.TabIndex = 7;
			// 
			// EncodedStackTextbox
			// 
			this.EncodedStackTextbox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.EncodedStackTextbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.EncodedStackTextbox.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.EncodedStackTextbox.Location = new System.Drawing.Point(1, 1);
			this.EncodedStackTextbox.Multiline = true;
			this.EncodedStackTextbox.Name = "EncodedStackTextbox";
			this.EncodedStackTextbox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.EncodedStackTextbox.Size = new System.Drawing.Size(716, 135);
			this.EncodedStackTextbox.TabIndex = 0;
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.Filter = "Dotfuscator map files|*.xml";
			this.openFileDialog1.Title = "Choose dotfuscator map file";
			// 
			// splitContainer1
			// 
			this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.splitContainer1.Location = new System.Drawing.Point(9, 62);
			this.splitContainer1.Name = "splitContainer1";
			this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.Controls.Add(this.DecodeClipboard);
			this.splitContainer1.Panel1.Controls.Add(this.DecodeButton);
			this.splitContainer1.Panel1.Controls.Add(this.EncodedStackTextbox);
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.Controls.Add(this.DecodedStackTextbox);
			this.splitContainer1.Size = new System.Drawing.Size(722, 353);
			this.splitContainer1.SplitterDistance = 170;
			this.splitContainer1.TabIndex = 9;
			// 
			// DecodeClipboard
			// 
			this.DecodeClipboard.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.DecodeClipboard.Location = new System.Drawing.Point(526, 140);
			this.DecodeClipboard.Name = "DecodeClipboard";
			this.DecodeClipboard.Size = new System.Drawing.Size(110, 23);
			this.DecodeClipboard.TabIndex = 2;
			this.DecodeClipboard.Text = "Decode clipboard";
			this.DecodeClipboard.UseVisualStyleBackColor = true;
			this.DecodeClipboard.Click += new System.EventHandler(this.DecodeClipboard_Click);
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(741, 24);
			this.menuStrip1.TabIndex = 10;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.amstudioscomToolStripMenuItem,
            this.donateToolStripMenuItem});
			this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
			this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
			this.fileToolStripMenuItem.Text = "File";
			// 
			// aboutToolStripMenuItem
			// 
			this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
			this.aboutToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.aboutToolStripMenuItem.Text = "About...";
			this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
			// 
			// amstudioscomToolStripMenuItem
			// 
			this.amstudioscomToolStripMenuItem.Name = "amstudioscomToolStripMenuItem";
			this.amstudioscomToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.amstudioscomToolStripMenuItem.Text = "1amstudios.com";
			this.amstudioscomToolStripMenuItem.Click += new System.EventHandler(this.amstudioscomToolStripMenuItem_Click);
			// 
			// donateToolStripMenuItem
			// 
			this.donateToolStripMenuItem.Name = "donateToolStripMenuItem";
			this.donateToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
			this.donateToolStripMenuItem.Text = "Donate";
			this.donateToolStripMenuItem.Click += new System.EventHandler(this.donateToolStripMenuItem_Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(741, 427);
			this.Controls.Add(this.splitContainer1);
			this.Controls.Add(this.MapPathTextbox);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.ChooseMapFileButton);
			this.Controls.Add(this.menuStrip1);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "MainForm";
			this.Text = "dotfuscator StackViewer - 1am Studios";
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel1.PerformLayout();
			this.splitContainer1.Panel2.ResumeLayout(false);
			this.splitContainer1.Panel2.PerformLayout();
			this.splitContainer1.ResumeLayout(false);
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

				private System.Windows.Forms.TextBox MapPathTextbox;
        private System.Windows.Forms.Button ChooseMapFileButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button DecodeButton;
        private System.Windows.Forms.TextBox DecodedStackTextbox;
				private System.Windows.Forms.TextBox EncodedStackTextbox;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SplitContainer splitContainer1;
				private System.Windows.Forms.Button DecodeClipboard;
				private System.Windows.Forms.MenuStrip menuStrip1;
				private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
				private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
				private System.Windows.Forms.ToolStripMenuItem amstudioscomToolStripMenuItem;
				private System.Windows.Forms.ToolStripMenuItem donateToolStripMenuItem;
    }
}

