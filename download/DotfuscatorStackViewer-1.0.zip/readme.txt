Dotfuscator StackViewer 1.0 - 1amstudios.com

Decode Dotfuscator obfuscated stack traces from your applications without a full version of Dotfuscator.

jeff@1amstudios.com