﻿namespace DemoApplication
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.LoadDefaultLibraryButton = new System.Windows.Forms.Button();
            this.LoadLibraryFromFileButton = new System.Windows.Forms.Button();
            this.DecryptFileButton = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.EncryptButton = new System.Windows.Forms.Button();
            this.AboutButton = new System.Windows.Forms.Button();
            this.AddPlaylistButton = new System.Windows.Forms.Button();
            this.RemovePlaylistButton = new System.Windows.Forms.Button();
            this.TracksDataGrid = new System.Windows.Forms.DataGridView();
            this.AddTrackButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.RemoveTrackButton = new System.Windows.Forms.Button();
            this.PlaylistsListBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SaveChangesButton = new System.Windows.Forms.Button();
            this.RemoveFromPlaylistButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TracksDataGrid)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LoadDefaultLibraryButton
            // 
            this.LoadDefaultLibraryButton.Location = new System.Drawing.Point(13, 11);
            this.LoadDefaultLibraryButton.Name = "LoadDefaultLibraryButton";
            this.LoadDefaultLibraryButton.Size = new System.Drawing.Size(163, 23);
            this.LoadDefaultLibraryButton.TabIndex = 4;
            this.LoadDefaultLibraryButton.Text = "Load default iTunes library";
            this.LoadDefaultLibraryButton.UseVisualStyleBackColor = true;
            this.LoadDefaultLibraryButton.Click += new System.EventHandler(this.LoadDefaultLibraryButton_Click);
            // 
            // LoadLibraryFromFileButton
            // 
            this.LoadLibraryFromFileButton.Location = new System.Drawing.Point(182, 11);
            this.LoadLibraryFromFileButton.Name = "LoadLibraryFromFileButton";
            this.LoadLibraryFromFileButton.Size = new System.Drawing.Size(163, 23);
            this.LoadLibraryFromFileButton.TabIndex = 5;
            this.LoadLibraryFromFileButton.Text = "Load iTunes library file...";
            this.LoadLibraryFromFileButton.UseVisualStyleBackColor = true;
            this.LoadLibraryFromFileButton.Click += new System.EventHandler(this.LoadLibraryFromFileButton_Click);
            // 
            // DecryptFileButton
            // 
            this.DecryptFileButton.Location = new System.Drawing.Point(496, 0);
            this.DecryptFileButton.Name = "DecryptFileButton";
            this.DecryptFileButton.Size = new System.Drawing.Size(102, 23);
            this.DecryptFileButton.TabIndex = 14;
            this.DecryptFileButton.Text = "Decrypt library";
            this.DecryptFileButton.UseVisualStyleBackColor = true;
            this.DecryptFileButton.Click += new System.EventHandler(this.DecryptFileButton_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 438);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(810, 22);
            this.statusStrip1.TabIndex = 15;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // EncryptButton
            // 
            this.EncryptButton.Location = new System.Drawing.Point(388, 0);
            this.EncryptButton.Name = "EncryptButton";
            this.EncryptButton.Size = new System.Drawing.Size(102, 23);
            this.EncryptButton.TabIndex = 16;
            this.EncryptButton.Text = "Encrypt library";
            this.EncryptButton.UseVisualStyleBackColor = true;
            this.EncryptButton.Click += new System.EventHandler(this.EncryptButton_Click);
            // 
            // AboutButton
            // 
            this.AboutButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AboutButton.Location = new System.Drawing.Point(696, 11);
            this.AboutButton.Name = "AboutButton";
            this.AboutButton.Size = new System.Drawing.Size(102, 23);
            this.AboutButton.TabIndex = 17;
            this.AboutButton.Text = "About...";
            this.AboutButton.UseVisualStyleBackColor = true;
            this.AboutButton.Click += new System.EventHandler(this.AboutButton_Click);
            // 
            // AddPlaylistButton
            // 
            this.AddPlaylistButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.AddPlaylistButton.Location = new System.Drawing.Point(6, 329);
            this.AddPlaylistButton.Name = "AddPlaylistButton";
            this.AddPlaylistButton.Size = new System.Drawing.Size(56, 23);
            this.AddPlaylistButton.TabIndex = 9;
            this.AddPlaylistButton.Text = "Add";
            this.AddPlaylistButton.UseVisualStyleBackColor = true;
            this.AddPlaylistButton.Click += new System.EventHandler(this.AddPlaylistButton_Click);
            // 
            // RemovePlaylistButton
            // 
            this.RemovePlaylistButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.RemovePlaylistButton.Location = new System.Drawing.Point(68, 329);
            this.RemovePlaylistButton.Name = "RemovePlaylistButton";
            this.RemovePlaylistButton.Size = new System.Drawing.Size(56, 23);
            this.RemovePlaylistButton.TabIndex = 10;
            this.RemovePlaylistButton.Text = "Remove";
            this.RemovePlaylistButton.UseVisualStyleBackColor = true;
            this.RemovePlaylistButton.Click += new System.EventHandler(this.RemovePlaylistButton_Click);
            // 
            // TracksDataGrid
            // 
            this.TracksDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.TracksDataGrid.BackgroundColor = System.Drawing.Color.White;
            this.TracksDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TracksDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TracksDataGrid.Location = new System.Drawing.Point(187, 33);
            this.TracksDataGrid.MultiSelect = false;
            this.TracksDataGrid.Name = "TracksDataGrid";
            this.TracksDataGrid.RowHeadersVisible = false;
            this.TracksDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.TracksDataGrid.Size = new System.Drawing.Size(592, 290);
            this.TracksDataGrid.TabIndex = 8;
            // 
            // AddTrackButton
            // 
            this.AddTrackButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.AddTrackButton.Location = new System.Drawing.Point(187, 329);
            this.AddTrackButton.Name = "AddTrackButton";
            this.AddTrackButton.Size = new System.Drawing.Size(128, 23);
            this.AddTrackButton.TabIndex = 11;
            this.AddTrackButton.Text = "Add track to library...";
            this.AddTrackButton.UseVisualStyleBackColor = true;
            this.AddTrackButton.Click += new System.EventHandler(this.AddTrackButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Playlists:";
            // 
            // RemoveTrackButton
            // 
            this.RemoveTrackButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.RemoveTrackButton.Location = new System.Drawing.Point(531, 329);
            this.RemoveTrackButton.Name = "RemoveTrackButton";
            this.RemoveTrackButton.Size = new System.Drawing.Size(118, 23);
            this.RemoveTrackButton.TabIndex = 12;
            this.RemoveTrackButton.Text = "Remove from library";
            this.RemoveTrackButton.UseVisualStyleBackColor = true;
            this.RemoveTrackButton.Click += new System.EventHandler(this.RemoveTrackButton_Click);
            // 
            // PlaylistsListBox
            // 
            this.PlaylistsListBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.PlaylistsListBox.FormattingEnabled = true;
            this.PlaylistsListBox.Location = new System.Drawing.Point(6, 33);
            this.PlaylistsListBox.Name = "PlaylistsListBox";
            this.PlaylistsListBox.Size = new System.Drawing.Size(164, 290);
            this.PlaylistsListBox.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(184, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Tracks:";
            // 
            // SaveChangesButton
            // 
            this.SaveChangesButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.SaveChangesButton.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveChangesButton.Location = new System.Drawing.Point(677, 347);
            this.SaveChangesButton.Name = "SaveChangesButton";
            this.SaveChangesButton.Size = new System.Drawing.Size(102, 23);
            this.SaveChangesButton.TabIndex = 14;
            this.SaveChangesButton.Text = "Save Changes";
            this.SaveChangesButton.UseVisualStyleBackColor = true;
            this.SaveChangesButton.Click += new System.EventHandler(this.SaveChangesButton_Click);
            // 
            // RemoveFromPlaylistButton
            // 
            this.RemoveFromPlaylistButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.RemoveFromPlaylistButton.Location = new System.Drawing.Point(397, 329);
            this.RemoveFromPlaylistButton.Name = "RemoveFromPlaylistButton";
            this.RemoveFromPlaylistButton.Size = new System.Drawing.Size(128, 23);
            this.RemoveFromPlaylistButton.TabIndex = 15;
            this.RemoveFromPlaylistButton.Text = "Remove from playlist";
            this.RemoveFromPlaylistButton.UseVisualStyleBackColor = true;
            this.RemoveFromPlaylistButton.Click += new System.EventHandler(this.RemoveFromPlaylistButton_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(342, 334);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Selection:";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.RemoveFromPlaylistButton);
            this.groupBox1.Controls.Add(this.SaveChangesButton);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.PlaylistsListBox);
            this.groupBox1.Controls.Add(this.RemoveTrackButton);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.AddTrackButton);
            this.groupBox1.Controls.Add(this.TracksDataGrid);
            this.groupBox1.Controls.Add(this.RemovePlaylistButton);
            this.groupBox1.Controls.Add(this.AddPlaylistButton);
            this.groupBox1.Enabled = false;
            this.groupBox1.Location = new System.Drawing.Point(13, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(785, 386);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 460);
            this.Controls.Add(this.AboutButton);
            this.Controls.Add(this.EncryptButton);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.DecryptFileButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.LoadLibraryFromFileButton);
            this.Controls.Add(this.LoadDefaultLibraryButton);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "MainForm";
            this.Text = "iTunes LibraryEditor demo";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TracksDataGrid)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button LoadDefaultLibraryButton;
        private System.Windows.Forms.Button LoadLibraryFromFileButton;
        private System.Windows.Forms.Button DecryptFileButton;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Button EncryptButton;
        private System.Windows.Forms.Button AboutButton;
        private System.Windows.Forms.Button AddPlaylistButton;
        private System.Windows.Forms.Button RemovePlaylistButton;
        private System.Windows.Forms.DataGridView TracksDataGrid;
        private System.Windows.Forms.Button AddTrackButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button RemoveTrackButton;
        private System.Windows.Forms.ListBox PlaylistsListBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button SaveChangesButton;
        private System.Windows.Forms.Button RemoveFromPlaylistButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

