﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using iTunesLibraryEditor;
using iTunesLibraryEditor.Exceptions;

namespace DemoApplication
{
    public partial class MainForm : Form
    {
        iTunesLibrary _library;

        public MainForm()
        {
            InitializeComponent();

            PlaylistsListBox.SelectedIndexChanged += new EventHandler(PlaylistsListBox_SelectedIndexChanged);

            DebugLogger.StartLogging("iTunes Library Demo.log");

            //This will disable the loading screen if a valid name/key is supplied.
            iTunesLibraryEditor.License.Set("name", "license key");

            this.FormClosed += new FormClosedEventHandler(MainForm_FormClosed);
        }

        void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            // This is not strictly necessary as file locks will be released when this process ends, but
            // good practice to clean up!
            if (_library != null)
                _library.ReleaseLock();
        }

        private void LoadDefaultLibraryButton_Click(object sender, EventArgs e)
        {
            try
            {
                _library = new iTunesLibrary();
                _library.AcquireLock();
                groupBox1.Enabled = true;
                RefreshUI();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadLibraryFromFileButton_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    _library = new iTunesLibrary(openFileDialog1.FileName);
                    groupBox1.Enabled = true;
                    RefreshUI();
                }
                catch (ParseException ex)
                {
                    MessageBox.Show(ex.Message, "Make sure you choose a valid .itl file");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        void PlaylistsListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindingSource source = new BindingSource();
            if (PlaylistsListBox.SelectedItem != null)
                source.DataSource = ((Playlist)PlaylistsListBox.SelectedItem).Tracks();
            TracksDataGrid.DataSource = source;
        }

        private void AddTrackButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    Track newTrack = _library.Tracks.Add(openFileDialog1.FileName);
                    RefreshUI();
                }
            }
            catch (TrackAlreadyExistsException ex)
            {
                MessageBox.Show("Track already exists, name: " + ex.ExistingTrack.Title);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void AddPlaylistButton_Click(object sender, EventArgs e)
        {
            try
            {
                AddPlaylistForm form = new AddPlaylistForm();
                if (form.ShowDialog() == DialogResult.OK)
                {
                    Playlist newPlaylist = _library.Playlists.Add(form.SelectedName);
                    newPlaylist.AddTrack(_library.Tracks[0]);
                    RefreshUI();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void RemovePlaylistButton_Click(object sender, EventArgs e)
        {
            try
            {
                Playlist toRemove = (Playlist)PlaylistsListBox.SelectedItem;
                _library.Playlists.Remove(toRemove);
                RefreshUI();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoveTrackButton_Click(object sender, EventArgs e)
        {
            try
            {
                Track selected = (Track)TracksDataGrid.SelectedRows[0].DataBoundItem;
                _library.Tracks.Remove(selected);
                RefreshUI();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoveFromPlaylistButton_Click(object sender, EventArgs e)
        {
            try
            {
                Track selected = (Track)TracksDataGrid.SelectedRows[0].DataBoundItem;
                Playlist playlist = (Playlist)PlaylistsListBox.SelectedItem;

                playlist.RemoveTrack(selected);
                RefreshUI();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SaveChangesButton_Click(object sender, EventArgs e)
        {
            try
            {
                _library.Backup();
                _library.SaveChanges();
                MessageBox.Show("iTunes library saved");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void RefreshUI()
        {
            groupBox1.Text = _library.FilePath;
            PlaylistsListBox.DataSource = null;
            PlaylistsListBox.DataSource = _library.Playlists.BindingList;
            toolStripStatusLabel1.Text = String.Format("Library: {0}, Version: {1}", _library.FilePath, _library.Version);
        }

        private void AboutButton_Click(object sender, EventArgs e)
        {
            AboutForm form = new AboutForm();
            form.ShowDialog();
        }

        #region For testing
        private void DecryptFileButton_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    iTunesLibrary lib = new iTunesLibrary(openFileDialog1.FileName);
                    lib.SaveChanges(lib.FilePath + "_decoded", false);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void EncryptButton_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    iTunesLibrary lib = new iTunesLibrary(openFileDialog1.FileName);
                    lib.SaveChanges(lib.FilePath.Replace("_decoded", ""), true);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        #endregion
    }
}