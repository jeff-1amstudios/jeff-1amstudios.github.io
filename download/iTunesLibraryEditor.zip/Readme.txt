-------------------------------------------------------------------------------------
iTunes LibraryEditor:	http://www.1amstudios.com/products/iTunesLibraryEditor
Version:		1.2.4
Author:			1am Studios / Jeffrey Harris

-------------------------------------------------------------------------------------

The iTunes Library Editor is a standard .NET 2.0 dll which can manipulate an iTunes library file (itl) without using the iTunes SDK.


Whats wrong with the iTunes SDK?

    * Its slow
    * iTunes starts and shows its main window. (And sync's connected iPods, downloads podcasts, etc.)
    * iTunes continues to run after you've finished.

By contrast, iTunes Library Editor:

    * Is very quick at loading of library files (< 1 second instead of 5-6 seconds for iTunes SDK)
    * Is simple to use - add and remove both tracks and playlists with a couple of lines of code
    * Has no need for iTunes to be running
    * Works with iTunes 6, 7, 8


Usage:

iTunesLibrary library = new iTunesLibrary();

//To add a track to your iTunes library:
Track newTrack = library.Tracks.Add("c:\\music\\mytrack.mp3");

//To add a playlist to your iTunes library:
Playlist newPlaylist = library.Playlists.Add("My new list");

//Add the new track to the new playlist
newPlaylist.AddTrack(newTrack);

//Save changes to the iTunes library file
library.SaveChanges();

-------------------------------------------------------------------------------------
License Information

To purchase a license for iTunes LibraryEditor, please visit the website - http://www.1amstudios.com/products/ituneslibraryeditor


For support, questions and sales information please contact us: support@1amstudios.com
