The files contained in FRONTEND and SIMDATA were produced by Pioneer Productions / EA Seattle in 1995.

The files in ConvertedAudio were pulled from the original .BNK files in the SIMDATA\SOUNDBNK folder and cleaned up with Audacity
