The Carmageddon Demo, SplatPack Demo and SplatPack Xmas Demo data files are:

(c) 1997 Stainless Software Ltd.
(c) 1997 SCi (Sales Curve Interactive) Ltd.     
All rights reserved. SCi is a trademark of SCi (Sales Curve Interactive) Ltd.


Please check the README.TXT file inside each folder for more details.